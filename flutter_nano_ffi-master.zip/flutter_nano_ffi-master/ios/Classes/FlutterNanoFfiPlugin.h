#import <Flutter/Flutter.h>

@interface FlutterNanoFfiPlugin : NSObject<FlutterPlugin>
@end
