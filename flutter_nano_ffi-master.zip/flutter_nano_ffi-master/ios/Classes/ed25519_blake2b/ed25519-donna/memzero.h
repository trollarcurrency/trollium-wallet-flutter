#ifndef __MEMZERO_H__
#define __MEMZERO_H__

#include <stddef.h>

void memzero(void *s, size_t n);

#endif