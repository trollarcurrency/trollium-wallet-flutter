## 2.0.0

* Migrate to null safety

## 1.0.3

* Fix a build warning

## 1.0.2

* Use C for all blake2b hash calculations (Account checksum, block hash calculation)

## 1.0.1

* Address pub analysis warnings

## 1.0.0

* Initial release
* Same API as [nanodart](https://pub.dev/packages/nanodart)
* Uses dart FFI to run ed25519/blake2b functions natively
